Friendly Touhou Allies for Doom

Assets and Sprites used: Doom II, Id Software.
                         Touhou Project, Team Shanghai Alice, Tasofro. 
Mod Author: papasrod 
Page Link: https://www.moddb.com/members/papa-pole 